The following assets to create Login Screen UI Design in MI App Inventor are there in the Folder:
1) Background Gradient
2) Close Icon
3) Login Button
4) User Icon
5) Roboto-Thin Font(.ttf File)
6) YourFont Extension .AIX File(created by Ken: https://community.appinventor.mit.edu/t/yourfont-extension-opensource/9131)

These images were created using a free designer website for beginners called Canva.
Canva Website: https://www.canva.com/

Please consider Subscribing for more tutorials.